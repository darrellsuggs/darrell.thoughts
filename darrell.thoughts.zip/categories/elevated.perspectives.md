---
layout: category
title: "Elevated Perspectives"
category: elevated.perspectives
permalink: /categories/elevated-perspectives/
author_profile: true
type: posts
taxonomy: category
entries_layout: grid
classes: wide
---
