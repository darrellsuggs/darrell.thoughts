---
layout: category
title: "Intentional Thinking"
category: intentional.thinking
permalink: /categories/intentional-thinking/
author_profile: true
type: posts
taxonomy: category
entries_layout: grid
classes: wide
---
