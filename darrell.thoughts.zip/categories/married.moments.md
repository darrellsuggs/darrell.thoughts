---
layout: category
title: "Married Moments"
category: married.moments
permalink: /categories/married-moments/
author_profile: true
type: posts
taxonomy: category
entries_layout: grid
classes: wide
---
