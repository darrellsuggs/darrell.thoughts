---
layout: category
title: "Other Thinkers"
category: other.thinkers
permalink: /categories/other-thinkers/
author_profile: true
type: posts
taxonomy: category
entries_layout: grid
classes: wide
---
