---
layout: category
title: "Dad Mode"
category: dad.mode
permalink: /categories/dad-mode/
author_profile: true
type: posts
taxonomy: category
entries_layout: grid
classes: wide
---
