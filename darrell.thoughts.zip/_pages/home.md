---
layout: single
title: ""
permalink: /
author_profile: true
sidebar:
  nav: "main"
---

Welcome to my categorized public blog. Use the navigation sidebar to explore by topic.

