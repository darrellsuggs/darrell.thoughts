---
layout: category
title: "Nerd Brain"
category: nerd.brain
permalink: /categories/nerd-brain/
author_profile: true
type: posts
taxonomy: category
entries_layout: grid
classes: wide
---
