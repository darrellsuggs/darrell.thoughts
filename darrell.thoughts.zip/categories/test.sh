mv writing.therapy.md writing-therapy.md
